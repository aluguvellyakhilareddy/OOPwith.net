﻿using System;
using System.Windows.Forms;

namespace Week3Application
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Random rand = new Random();
            int num1 = rand.Next(1, 10);
            int num2 = rand.Next(1, 10);
            number.Text = num1.ToString();
            number2.Text = num2.ToString();

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {

        }
        private void Add_CheckedChanged(object sender, EventArgs e)
        {
            Operator.Text = "+";
            num.Text = String.Empty;
            AnswerLabel.Text = String.Empty;
        }


        private void Subtract_CheckedChanged(object sender, EventArgs e)
        {
            Operator.Text = "-";
            num.Text = String.Empty;
            AnswerLabel.Text = String.Empty;
        }

        private void Multiply_CheckedChanged(object sender, EventArgs e)
        {
            Operator.Text = "*";
            num.Text = String.Empty;
            AnswerLabel.Text = String.Empty;
        }

        private void Divide_CheckedChanged(object sender, EventArgs e)
        {
            Operator.Text = "/";

        }

        private void number_TextChanged(object sender, EventArgs e)
        {

        }

        private void number2_TextChanged(object sender, EventArgs e)
        {

        }

        private void num_TextChanged(object sender, EventArgs e)
        {

        }

        private void CheckButton_Click(object sender, EventArgs e)
        {
        }


        private void next_Click(object sender, EventArgs e)
        {
            Random rand = new Random();
            int num1 = rand.Next(1, 10);
            int num2 = rand.Next(1, 10);

            number.Text = num1.ToString();
            number2.Text = num2.ToString();

            num.Text = String.Empty;
            AnswerLabel.Text = String.Empty;


        }
        private void right_Click_1(object sender, EventArgs e)
        {

            if (Add.Checked == true)
            {

                int value1 = int.TryParse(number.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(num.Text, out value3) ? value3 : 1;

                int result = value1 + value2;

                if (value3 == result)
                {
                    AnswerLabel.Text = "Correct :)";
                }
                else
                {
                    AnswerLabel.Text = "Incorrect :( - Right answer was " + result;
                }

            }



            if (Subtract.Checked == true)
            {

                int value1 = int.TryParse(number.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(num.Text, out value3) ? value3 : 1;

                int result = value1 - value2;

                if (value3 == result)
                {
                    AnswerLabel.Text = "Correct :)";
                }
                else
                {
                    AnswerLabel.Text = "Incorrect :( - Right answer was " + result;
                }

            }


            if (Multiply.Checked == true)
            {

                int value1 = int.TryParse(number.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(num.Text, out value3) ? value3 : 1;

                int result = value1 * value2;

                if (value3 == result)
                {
                    AnswerLabel.Text = "Correct :)";
                }
                else
                {
                    AnswerLabel.Text = "Incorrect :( - Right answer was " + result;
                }

            }


            if (Divide.Checked == true)
            {

                int value1 = int.TryParse(number.Text, out value1) ? value1 : 1;
                int value2 = int.TryParse(number2.Text, out value2) ? value2 : 1;
                int value3 = int.TryParse(num.Text, out value3) ? value3 : 1;

                int result = value1 / value2;

                if (value3 == result)
                {
                    AnswerLabel.Text = "Correct :)";
                }
                else
                {
                    AnswerLabel.Text = "Incorrect :( - Right answer was " + result;
                }





            }
        
        }

        private void done_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

