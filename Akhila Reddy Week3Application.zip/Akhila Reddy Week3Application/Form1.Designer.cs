﻿namespace Week3Application
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.Divide = new System.Windows.Forms.RadioButton();
            this.Multiply = new System.Windows.Forms.RadioButton();
            this.Subtract = new System.Windows.Forms.RadioButton();
            this.Add = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.done = new System.Windows.Forms.Button();
            this.right = new System.Windows.Forms.Button();
            this.next = new System.Windows.Forms.Button();
            this.calculation = new System.Windows.Forms.GroupBox();
            this.equalsign = new System.Windows.Forms.Label();
            this.Operator = new System.Windows.Forms.Label();
            this.num = new System.Windows.Forms.TextBox();
            this.number2 = new System.Windows.Forms.TextBox();
            this.number = new System.Windows.Forms.TextBox();
            this.Result = new System.Windows.Forms.GroupBox();
            this.AnswerLabel = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.calculation.SuspendLayout();
            this.Result.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.Divide);
            this.groupBox1.Controls.Add(this.Multiply);
            this.groupBox1.Controls.Add(this.Subtract);
            this.groupBox1.Controls.Add(this.Add);
            this.groupBox1.Location = new System.Drawing.Point(31, 14);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(5);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(5);
            this.groupBox1.Size = new System.Drawing.Size(985, 143);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Select an equation Type";
            // 
            // Divide
            // 
            this.Divide.AutoSize = true;
            this.Divide.Location = new System.Drawing.Point(799, 74);
            this.Divide.Margin = new System.Windows.Forms.Padding(5);
            this.Divide.Name = "Divide";
            this.Divide.Size = new System.Drawing.Size(119, 33);
            this.Divide.TabIndex = 3;
            this.Divide.TabStop = true;
            this.Divide.Text = "Division";
            this.Divide.UseVisualStyleBackColor = true;
            this.Divide.CheckedChanged += new System.EventHandler(this.Divide_CheckedChanged);
            // 
            // Multiply
            // 
            this.Multiply.AutoSize = true;
            this.Multiply.Location = new System.Drawing.Point(516, 74);
            this.Multiply.Margin = new System.Windows.Forms.Padding(5);
            this.Multiply.Name = "Multiply";
            this.Multiply.Size = new System.Drawing.Size(175, 33);
            this.Multiply.TabIndex = 2;
            this.Multiply.TabStop = true;
            this.Multiply.Text = "Multiplication";
            this.Multiply.UseVisualStyleBackColor = true;
            this.Multiply.CheckedChanged += new System.EventHandler(this.Multiply_CheckedChanged);
            // 
            // Subtract
            // 
            this.Subtract.AutoSize = true;
            this.Subtract.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Subtract.Location = new System.Drawing.Point(249, 74);
            this.Subtract.Margin = new System.Windows.Forms.Padding(5);
            this.Subtract.Name = "Subtract";
            this.Subtract.Size = new System.Drawing.Size(155, 33);
            this.Subtract.TabIndex = 1;
            this.Subtract.TabStop = true;
            this.Subtract.Text = "Subtraction";
            this.Subtract.UseVisualStyleBackColor = true;
            this.Subtract.CheckedChanged += new System.EventHandler(this.Subtract_CheckedChanged);
            // 
            // Add
            // 
            this.Add.AutoSize = true;
            this.Add.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Add.Location = new System.Drawing.Point(51, 74);
            this.Add.Margin = new System.Windows.Forms.Padding(5);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(122, 33);
            this.Add.TabIndex = 0;
            this.Add.TabStop = true;
            this.Add.Text = "Addition";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.CheckedChanged += new System.EventHandler(this.Add_CheckedChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(733, 384);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(0, 29);
            this.label2.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(681, 395);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 29);
            this.label1.TabIndex = 6;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.done);
            this.groupBox2.Controls.Add(this.right);
            this.groupBox2.Controls.Add(this.next);
            this.groupBox2.Location = new System.Drawing.Point(33, 341);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(987, 138);
            this.groupBox2.TabIndex = 12;
            this.groupBox2.TabStop = false;
            // 
            // done
            // 
            this.done.Location = new System.Drawing.Point(735, 58);
            this.done.Name = "done";
            this.done.Size = new System.Drawing.Size(141, 43);
            this.done.TabIndex = 2;
            this.done.Text = "I\'m Done";
            this.done.UseVisualStyleBackColor = true;
            this.done.Click += new System.EventHandler(this.done_Click);
            // 
            // right
            // 
            this.right.Location = new System.Drawing.Point(417, 58);
            this.right.Name = "right";
            this.right.Size = new System.Drawing.Size(145, 43);
            this.right.TabIndex = 1;
            this.right.Text = "Am I Right?";
            this.right.UseVisualStyleBackColor = true;
            this.right.Click += new System.EventHandler(this.right_Click_1);
            // 
            // next
            // 
            this.next.Location = new System.Drawing.Point(35, 58);
            this.next.Name = "next";
            this.next.Size = new System.Drawing.Size(233, 42);
            this.next.TabIndex = 0;
            this.next.Text = "Next Question";
            this.next.UseVisualStyleBackColor = true;
            this.next.Click += new System.EventHandler(this.next_Click);
            // 
            // calculation
            // 
            this.calculation.Controls.Add(this.equalsign);
            this.calculation.Controls.Add(this.Operator);
            this.calculation.Controls.Add(this.num);
            this.calculation.Controls.Add(this.number2);
            this.calculation.Controls.Add(this.number);
            this.calculation.Location = new System.Drawing.Point(33, 176);
            this.calculation.Name = "calculation";
            this.calculation.Size = new System.Drawing.Size(985, 159);
            this.calculation.TabIndex = 13;
            this.calculation.TabStop = false;
            this.calculation.Text = "Can you answer this question";
            // 
            // equalsign
            // 
            this.equalsign.AutoSize = true;
            this.equalsign.Location = new System.Drawing.Point(634, 81);
            this.equalsign.Name = "equalsign";
            this.equalsign.Size = new System.Drawing.Size(27, 29);
            this.equalsign.TabIndex = 4;
            this.equalsign.Text = "=";
            // 
            // Operator
            // 
            this.Operator.AutoSize = true;
            this.Operator.Location = new System.Drawing.Point(278, 76);
            this.Operator.Name = "Operator";
            this.Operator.Size = new System.Drawing.Size(27, 29);
            this.Operator.TabIndex = 3;
            this.Operator.Text = "+";
            // 
            // num
            // 
            this.num.Location = new System.Drawing.Point(708, 78);
            this.num.Name = "num";
            this.num.Size = new System.Drawing.Size(100, 34);
            this.num.TabIndex = 2;
            this.num.TextChanged += new System.EventHandler(this.num_TextChanged);
            // 
            // number2
            // 
            this.number2.Location = new System.Drawing.Point(417, 76);
            this.number2.Name = "number2";
            this.number2.Size = new System.Drawing.Size(100, 34);
            this.number2.TabIndex = 1;
            // 
            // number
            // 
            this.number.Location = new System.Drawing.Point(35, 73);
            this.number.Name = "number";
            this.number.Size = new System.Drawing.Size(100, 34);
            this.number.TabIndex = 0;
            // 
            // Result
            // 
            this.Result.Controls.Add(this.AnswerLabel);
            this.Result.Location = new System.Drawing.Point(33, 485);
            this.Result.Name = "Result";
            this.Result.Size = new System.Drawing.Size(987, 80);
            this.Result.TabIndex = 14;
            this.Result.TabStop = false;
            // 
            // AnswerLabel
            // 
            this.AnswerLabel.AutoSize = true;
            this.AnswerLabel.Location = new System.Drawing.Point(340, 34);
            this.AnswerLabel.Name = "AnswerLabel";
            this.AnswerLabel.Size = new System.Drawing.Size(79, 29);
            this.AnswerLabel.TabIndex = 0;
            this.AnswerLabel.Text = "label3";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 29F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1065, 587);
            this.Controls.Add(this.Result);
            this.Controls.Add(this.calculation);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.Text = "Math Practice";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.calculation.ResumeLayout(false);
            this.calculation.PerformLayout();
            this.Result.ResumeLayout(false);
            this.Result.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton Subtract;
        private System.Windows.Forms.RadioButton Add;
        private System.Windows.Forms.RadioButton Divide;
        private System.Windows.Forms.RadioButton Multiply;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button done;
        private System.Windows.Forms.Button right;
        private System.Windows.Forms.Button next;
        private System.Windows.Forms.GroupBox calculation;
        private System.Windows.Forms.Label equalsign;
        private System.Windows.Forms.Label Operator;
        private System.Windows.Forms.TextBox num;
        private System.Windows.Forms.TextBox number2;
        private System.Windows.Forms.TextBox number;
        private System.Windows.Forms.GroupBox Result;
        private System.Windows.Forms.Label AnswerLabel;
    }
}

